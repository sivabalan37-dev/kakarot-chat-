const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

// Sends a push notification to the receiver's devices whenever a new message is created.
// Set region to where your Firestore database lives (us-central1 works for US locations).
exports.notifyNewMessage = onDocumentCreated({ document: "messages/{id}", region: "us-central1" }, async (event) => {
  const m = event.data && event.data.data();
  if (!m || !m.receiver_id || !m.sender_id) return;
  const db = getFirestore();
  const [user, sender, blocked] = await Promise.all([
    db.doc(`users/${m.receiver_id}`).get(),
    db.doc(`profiles/${m.sender_id}`).get(),
    db.doc(`users/${m.receiver_id}/blocked/${m.sender_id}`).get(),
  ]);
  const tokens = (user.data() || {}).fcm_tokens || [];
  if (!tokens.length || blocked.exists) return;
  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: (sender.data() || {}).username || "New message", body: String(m.text || "").slice(0, 140) },
    data: { chat_id: String(m.chat_id || "") },
    android: { priority: "high" },
  });
  // forget devices that no longer exist
  const dead = tokens.filter((t, i) => !res.responses[i].success && /not-registered|invalid-registration|invalid-argument/.test(res.responses[i].error.code));
  if (dead.length) await user.ref.update({ fcm_tokens: FieldValue.arrayRemove(...dead) });
});
