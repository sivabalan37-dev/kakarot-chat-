// Optional: sends a push to the recipient when a message is created. Requires the Blaze plan.
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

exports.notify = onDocumentCreated('chats/{chat}/messages/{msg}', async e => {
  const m = e.data.data();
  const chat = (await db.doc('chats/' + e.params.chat).get()).data();
  const to = chat.members.find(u => u !== m.from);
  const [t, from] = await Promise.all([db.doc('tokens/' + to).get(), db.doc('users/' + m.from).get()]);
  const tokens = (t.data() || {}).t || [];
  if (!tokens.length) return;
  const r = await admin.messaging().sendEachForMulticast({
    tokens,
    data: { title: (from.data() || {}).name || 'Kakarot Chat', body: String(m.text).slice(0, 120), chat: e.params.chat },
  });
  const dead = tokens.filter((_, i) => !r.responses[i].success && /not-registered|invalid-registration/.test(r.responses[i].error.code));
  if (dead.length) await t.ref.update({ t: admin.firestore.FieldValue.arrayRemove(...dead) });
});
